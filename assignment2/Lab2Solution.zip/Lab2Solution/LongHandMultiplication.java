
public class LongHandMultiplication {

	public static String Binary(String a,String b){
// convert a and b string into reverse using StringBuilder class
// create two instances n1 and n2 of StringBuilder() class
		String n1=new StringBuilder(a).reverse().toString();
		String n2=new StringBuilder(b).reverse().toString();
		int[] d=new int[a.length()+b.length()]; // two strings length into single array d

// multiply each digit and sum at the corresponding positions
			for(int i=0;i<n1.length();i++){
				for(int j=0;j<n2.length();j++)
					d[i+j]+=(n1.charAt(i)-'0') * (n2.charAt(j)-'0');
			}
				StringBuilder sb = new StringBuilder(); // create instance sb fro StringBuilder()
 
						for(int i=0; i<d.length; i++){ // create for loop
								int m = d[i]%2; // calculate remainder store into m
								int c = d[i]/2; // retrieve carry bits into c
								if(i+1<d.length){ // check condition
									d[i+1] += c; // store carry bit into array d
								}
									sb.insert(0, m); // using StringBuilder object sb adding of remainder bits
						}

						while(sb.charAt(0) == '0' && sb.length()> 1){ //create while loop first bit 0
							sb.deleteCharAt(0); // delete first bits 0
							}

									return sb.toString(); // return sb object
							}

	public static void main(String args[]){ 
		long t1, t2;
		double dt;
			t1 = System.currentTimeMillis();
			// input for test case
			String x= "11110000";String y= "10111100";
			String c= "1111000";String d= "111100";
			String e= "11110000";String f="1111000";
			String g= "111100000";String h="11110000";
			String I= "1111000000";String J="111100000";


			System.out.println("Multiplied a and b Value is:"+Binary(x,y)); 
				t2 = System.currentTimeMillis();
				dt = t2 - t1;
					System.out.println("Input has running time: " + dt + ".");
			System.out.println("Multiplied a and b Value is: "+Binary(c,d)); 
				t2 = System.currentTimeMillis();
				dt = t2 - t1;
					System.out.println("Input has running time: " + dt + ".");
			System.out.println("Multiplied a and b Value is: "+Binary(e,f)); 
				t2 = System.currentTimeMillis();
				dt = t2 - t1;
					System.out.println("Input has running time: " + dt + ".");
			System.out.println("Multiplied a and b Value is: "+Binary(g,h)); 
				t2 = System.currentTimeMillis();
				dt = t2 - t1;
					System.out.println("Input has running time: " + dt + ".");
			System.out.println("Multiplied a and b Value is: "+Binary(I,J)); 
				t2 = System.currentTimeMillis();
				dt = t2 - t1;
					System.out.println("Input has running time: " + dt + ".");
		}

	}

