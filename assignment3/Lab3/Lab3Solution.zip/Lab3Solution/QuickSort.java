import java.util.Random;
import java.util.Arrays;

public class QuickSort {
		public static void main(String[] args) {
			long t1, t2;
			double dt;
			t1 = System.currentTimeMillis();
			int [] A = new int[1000]; 
		    Random rand = new Random();
		    System.out.println("*******test case1***********");
	    	System.out.println("Randomly Generated Number");		  
	    	for (int i=0; i<A.length; i++) {
		    	A[i] = rand.nextInt((1000 - 0) + 1) + 0;
		    	System.out.print(A[i] + " ");
				
		    	}
	    	Arrays.sort(A);// array sorting 
    		System.out.println();	    
    		System.out.println("Number sorted using array sort method");
    		printA(A);// print number after sorting using array sorting 
    		System.out.println();	
		    System.out.println("Numbers Sorted Using Quicksort Method");
	        quickSort(A, 0, A.length - 1);
	        printA(A);
	        t2 = System.currentTimeMillis();
		    dt = t2 - t1;
		    System.out.println();
		    System.out.println("Input has running time: " + dt);//running time for test case 1
		    
		    /**********test case 2************/
		    System.out.println();
		    System.out.println("*******test case2***********");
		    int [] B = new int[1000];
		    Random randm = new Random();
		    System.out.println("Randomly Generated Number");		  
	    	for (int i=0; i<B.length; i++) {
		    	B[i] = randm.nextInt((1000 - 0) + 1) + 0;
		    	System.out.print(B[i] + " ");
          	}
	    	Arrays.sort(B);    
		    System.out.println();
    		System.out.println("Number sorted using array sort method");
    		printA(B);// print number after the
    		System.out.println();
		    System.out.println("Numbers Sorted Using Quicksort Method with the median-of-3 pivot choice");
		    medianOf3(B, 0, B.length - 1);
		    printA(B);
		    t2 = System.currentTimeMillis();
		    dt = t2 - t1;
		    System.out.println();
		    System.out.println("Input has running time: " + dt);//running time for test case 1
		}
		
		private static void swapValues(int[] A, int p, int r) {

	        int temp = A[p];

	        A[p] = A[r];

	        A[r] = temp;

	    }
    private static int partition(int[] A, int p, int r) { // Lomuto partitioning scheme

	        int pivot = A[r];

	        int currentElement = p;

	        for (int i = p; i < r; i++) {

	            if(A[i] < pivot) {

	                swapValues(A, i, currentElement);
	                currentElement++;
            }

	        }

	        swapValues(A, r, currentElement);

	        return currentElement;

	    }

	    public static void quickSort(int[] A, int p, int r) {

	        if(p >= r) {

	            return;

	        } else {

	            int part = partition(A, p, r);

	            quickSort(A, p, part - 1);

	            quickSort(A, part + 1, r);

	        }

	    }	    
	    public static void printA(int[] A) {
	    	
	        for (int i = 0; i < A.length; i++) {
	        	
	          System.out.print(A[i] + " ");
	          }
	    	}
	    public static int medianOf3(int[] intArray, int left, int right) {
	        int center = (left + right) / 2;

	        if (intArray[left] > intArray[center])
	        	swapValues(intArray, left, center);

	        if (intArray[left] > intArray[right])
	        	swapValues(intArray, left, right);

	        if (intArray[center] > intArray[right])
	        	swapValues(intArray, center, right);

	        swapValues(intArray, center, right - 1);
	        return intArray[right - 1];
	      }
	}
