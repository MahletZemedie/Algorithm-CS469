import java.util.*;
import java.util.Arrays; 

public class InsertionSort{

	public static void main(String[] args) {
		long t1, t2;
		double dt;
		t1 = System.currentTimeMillis();	
		//test case1
		System.out.println("*******test case1***********");
		int[] anArray = new int[1000]; 
	    Random rand = new Random();
    	System.out.println("Randomly Generted Number");
	    	for (int i=0; i<anArray.length; i++) {
	    		anArray[i] = rand.nextInt((1000 - 0) + 1) + 0;
	    		System.out.print(anArray[i] + " ");// print the randomly generated number
	    	}
	    		Arrays.sort(anArray);// array sorting 
	    		System.out.println();	    
	    		System.out.println("Number sorted using array sort method for best-case  ");
	    		printArray(anArray);// print number after the
 
	    		System.out.println();	
	    		System.out.println("Numbers Sorted using Insertion Sort method ");
	    		insertionSort(anArray);
	    		printArray(anArray);
	    		t2 = System.currentTimeMillis();
	    		dt = t2 - t1;
	    		System.out.println();
	    		System.out.println("Input has running time: " + dt);//running time test case 1
	    		System.out.println();
	    		
	    		//test case2	    		
	    		System.out.println("*******test case2***********");
	    		System.out.println("Array in reverse order");
	    		Reverse(anArray);
	    		printArray(anArray);// print reverse order of the input array
	    		System.out.println();	
	    		System.out.println("Numbers after sort ");
	    		insertionSort(anArray);
	    		printArray(anArray);//print the sorted array using insertion sort
	    		t2 = System.currentTimeMillis();
	    		dt = t2 - t1;
	    		System.out.println();
	    		System.out.println("Input has running time: " + dt);
	    		System.out.println();
	    		
	    		//test case3
	    		System.out.println("*******test case3***********");
	    		//)Manually populate an  array with fixed,same value for all elements
	    		int [] SameNumbers = new  int [] {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};
	    		System.out.println();
	    		System.out.println("Array same value for all elements");
	    		printArray(SameNumbers);//print same numbers
	    		System.out.println();
	    		System.out.println(" Numbers after Sorted by Insertion sort method");
	    		insertionSort(SameNumbers);
	    		printArray(SameNumbers); //print sorted array by insertion sort method
	    		t2 = System.currentTimeMillis();
	    		dt = t2 - t1;
	    		System.out.println();
	    		System.out.println("Input has running time: " + dt);//running time for test case three
	    		System.out.println();
	    		
	    		//test case four
	    		System.out.println("*******test case4***********");
	    		//using reverse insertion sort for sorted array input
	    		System.out.println("sorted Numbers input");
				insertionSort(anArray);
	    		printArray(anArray);
	    		System.out.println();
	    		System.out.println("Insertion Sort Descending");
	    		InsertionSortReverse(anArray);//reverse insertion sort
	    		printArray(anArray);
	    		t2 = System.currentTimeMillis();
	    		dt = t2 - t1;
	    		System.out.println();
	    		System.out.println("Input has running time: " + dt);//running time for test case four
	}	
/*
 * Insertion method for sorting an array
 * 
 */
public static void insertionSort(int array[]) {
	int key, i;
	
    for (int j = 1; j < array.length; j++) {
        key = array[j];
        i = j - 1;
        while(i >= 0 && array[i] > key) {
            array[i + 1] = array[i];
            i = i - 1;
        }
        array[i + 1] = key;
		
	}
    
    }
//Insertion Sort Method for Descending Order
public static void InsertionSortReverse( int [] num)
{
     int j;                    
     int key;               
     int i;  

     for (j = 1; j < num.length; j++)   
    {
           key = num[ j ];
           for(i = j - 1; (i >= 0) && (num[ i ] < key); i--)   
          {
                 num[ i+1 ] = num[ i ];
          }
         num[ i+1 ] = key;    
     }
}
/*
 * method to print
 * 
 */
public static void printArray(int[] array) {
	
    for (int i = 0; i < array.length; i++) {
    	
      System.out.print(array[i] + " ");
      }
	}
/*
 * reverse method
 * 
 */
public static void Reverse(int [] array) {
	
	for(int i=0; i<array.length/2; i++){ 
		int temp = array[i]; 
		array[i] = array[array.length -i -1];
		array[array.length -i -1] = temp;
		
	}

}

}
